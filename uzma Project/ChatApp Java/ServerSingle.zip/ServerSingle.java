import java.io.*;
import java.net.*;

public class ServerSingle extends Thread{  

static Socket connectedSocket[]=new Socket[100];
static String dataArray[]=new String[1000];
static int dataCount=-1;
static int socketCount=-1;
static Socket socket;
String name="";

  public void run() {
    try
    {
      while(true)
   
        {
      
              DataInputStream din=new DataInputStream(socket.getInputStream()); 
              String str="";

              str=din.readUTF();  
             // System.out.println(name+" says : "+str); 
              dataCount++;
              dataArray[dataCount]=name+" says : "+str;
              broadcast();
        }
    }

    catch(IOException e){} 
  }

  static public void broadcast() throws IOException{

      for(int i=0;i<=socketCount;i++)
          {
              System.out.println(connectedSocket[i]);  

              DataOutputStream dout=new DataOutputStream(connectedSocket[i].getOutputStream());  

              for(int j=0;j<=dataCount;j++)
              {
                dout.writeUTF(dataArray[j]);
                dout.flush(); 
                System.out.println(dataArray[j]);
              }


          } 
  }
 
  public static void main(String[] args) throws Exception {
    

    ServerSocket s = new ServerSocket(3333);

    System.out.println("Server Started");

    try {

      while(true) {
       
        socket = s.accept();
        socketCount++;
        connectedSocket[socketCount]=socket;

        DataInputStream din1=new DataInputStream(socket.getInputStream());

        ServerSingle ss=new ServerSingle();
        ss.name=din1.readUTF();

        ss.start();
        
      } 
        
    }

    finally {

      s.close();
    }
  } 
}